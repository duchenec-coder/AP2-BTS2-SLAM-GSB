﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace proto_sqlServer_classe
{
    class globale
    {
        public static SqlConnection cnx;
        public static List <client> lesClients;
    }
}
